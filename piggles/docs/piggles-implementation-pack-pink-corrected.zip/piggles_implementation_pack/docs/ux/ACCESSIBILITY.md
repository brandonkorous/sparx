# Accessibility

Target WCAG 2.2 AA.

## Required

- keyboard-accessible MDI
- visible focus states
- logical focus order
- accessible names for windows and controls
- color contrast
- no color-only status meaning
- reduced-motion support
- scalable text
- screen-reader labels
- form errors associated with fields
- clear validation
- accessible modal/window behavior
- usable target sizes
- captions/transcripts for instructional media where practical

## Pink contrast caution

The primary pink may not be suitable for small text on white.

Use pink primarily as:
- accent
- icon fill
- large graphic element
- tinted surface/background
- interactive emphasis where contrast passes

Use dark charcoal for primary readable text.
