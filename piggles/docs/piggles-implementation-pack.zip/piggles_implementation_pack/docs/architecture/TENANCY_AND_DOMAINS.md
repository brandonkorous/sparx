# Tenancy and Domain Architecture

## Principle

Customer-hosted/public tenant content should live on a separate registrable domain from the platform/auth brand to protect cookie, reputation, SEO, and content isolation boundaries.

## Preferred tenant pattern

If available:
- `*.piggles.site` — tenant sites
- `customers.piggles.site` — CNAME target for custom domains
- `piggles.site` — apex redirect to `meetpiggles.com`

Example: `bobsbarber.piggles.site`

## Platform domains

- `meetpiggles.com`
- `getpiggles.com`
- `mypiggles.com`
- `api.mypiggles.com`
- `mcp.mypiggles.com`
- `status.meetpiggles.com`

## Email infrastructure

Preferred if available:
- `piggles.email`
- `mail.piggles.email`

## SEO/module domains

Potential acquisition domains:
- `pigglescms.com`
- `pigglescrm.com`
- `pigglesemail.com`
- `pigglesb2b.com`
- `pigglessite.com`
- `pigglesstore.com`
- `pigglesbookings.com`
- `pigglesapi.com`
- `pigglesmcp.com`

Do not fragment canonical docs across these domains.
