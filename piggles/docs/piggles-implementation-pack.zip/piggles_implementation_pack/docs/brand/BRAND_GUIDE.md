# Piggles Brand Guide

## Brand name

**Piggles**

## Tagline

**Business software for people who have a business to run.**

## Brand idea

Piggles makes serious business software feel approachable without making the work feel trivial.

## Mark

Primary mark:
- rounded capital-P silhouette;
- pig snout integrated into the bowl/counter;
- simple enough for favicon/app icon;
- recognizable at small sizes;
- no unnecessary facial detail.

## Wordmark

- very round primary display type;
- thick strokes;
- soft curves;
- rounded terminals;
- friendly but not childish;
- dark navy/charcoal primary wordmark.

## Color direction

Primary accent: warm Piggles yellow.  
Primary neutral: deep navy/charcoal.  
Supporting: cream/off-white, pale warm yellow, neutral gray.

Exact production values should be validated for accessibility and print. Starting tokens are in `config/brand.tokens.json`.

## Why yellow

Yellow separates Piggles from obvious pink-pig branding, creates warmth and memorability, feels optimistic and energetic, contrasts well with charcoal, and translates well into signage, print, leather, embroidery, enamel, and digital UI.

## Character

Piggles is a brand character, not a cartoon product.

Personality:
- warm
- capable
- slightly mischievous
- confident
- observant
- helpful
- never condescending

## Visual language

Use generous whitespace, rounded surfaces, strong dark text, warm accent, tactile applications, simple illustration, quality materials, and clean iconography.

Avoid generic SaaS gradients everywhere, juvenile pig drawings, farm/barn clichés, excessive pig puns, and cluttered enterprise dashboards.

## Approved material explorations

- debossed leather badge
- heritage/historical badge
- embroidered patch
- enamel pin
- neon signage
- letterpress/foil
- carved wood
- wax seal
- premium packaging

These are applications, not alternate master logos.

## Logo rules

Always preserve mark proportions, snout readability, clear space, contrast, and favicon legibility.

Do not stretch, arbitrarily rotate, add ears/eyes to the P mark, use joke treatments, or place it over noisy backgrounds without containment.

## Brand vs product

The brand may be playful. Work surfaces should remain calm, clear, and competent. The user can smile at Piggles without feeling like they are using a children's app.
