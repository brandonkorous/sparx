# Billing Rules

## Base subscription

- SKU: `piggles_base_monthly`
- target: $49/month
- all normal Piggles apps included

## Trial

Recommended initial posture: 14 days, no card required unless unit economics dictate otherwise.

## Capacity warnings

Warn at 80%, 95%, and 100%.

At threshold:
- explain exactly what capacity is constrained;
- provide a grace path where safe;
- offer one clear expansion action.

## Users

Suggested starting allowance: 3 included. Additional users are capacity expansion.

## Billing ownership

Get Piggles should own plan selection, payment setup, capacity upgrades, and payment recovery. My Piggles may link into billing but should not duplicate billing logic.
