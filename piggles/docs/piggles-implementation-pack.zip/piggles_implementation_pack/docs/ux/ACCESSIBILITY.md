# Accessibility

Target WCAG 2.2 AA.

## Required

- keyboard-accessible MDI
- visible focus states
- logical focus order
- accessible names for windows and controls
- color contrast
- no color-only status meaning
- reduced-motion support
- scalable text
- screen-reader labels
- form errors associated with fields
- clear validation
- accessible modal/window behavior
- usable target sizes
- captions/transcripts for instructional media where practical

## Yellow caution

Primary yellow may not be suitable for small text on white. Use yellow primarily as accent, icon fill, background tint, and large graphic element. Use dark charcoal for readable text.
