# USAGE_MATRIX

| Asset | Suggested use |
|---|---|
| piggles-calendar | bookings and scheduling |
| piggles-celebrate | success and completion |
| piggles-desk-scene | hero/auth/onboarding |
| piggles-invoice | invoices and billing |
| piggles-laptop | work and app support |
| piggles-neutral | generic support |
| piggles-point-left | directional guidance |
| piggles-thinking | help and discovery |
| piggles-wave | welcome and greetings |
