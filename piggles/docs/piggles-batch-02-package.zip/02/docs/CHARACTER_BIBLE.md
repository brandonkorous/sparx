# CHARACTER_BIBLE

Piggles is a rounded pink mascot in a soft premium 3D style.
