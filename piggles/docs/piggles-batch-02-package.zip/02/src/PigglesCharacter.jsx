import React from "react";
import pigglesCharacters from "./pigglesCharacters";
export function PigglesCharacter({ character = "wave", format = "webp", alt, className = "", ...props }) {
  const asset = pigglesCharacters[character];
  if (!asset) return null;
  const src = format === "png" ? asset.png : asset.webp;
  return <img src={src} alt={alt ?? asset.alt} className={className} {...props} />;
}
export default PigglesCharacter;
