export interface PigglesCharacterAsset { id: string; png: string; webp: string; alt: string; }
export interface PigglesCharactersMap {
  calendar: PigglesCharacterAsset; celebrate: PigglesCharacterAsset; deskScene: PigglesCharacterAsset;
  invoice: PigglesCharacterAsset; laptop: PigglesCharacterAsset; neutral: PigglesCharacterAsset;
  pointLeft: PigglesCharacterAsset; thinking: PigglesCharacterAsset; wave: PigglesCharacterAsset;
}
export const pigglesCharacters: PigglesCharactersMap;
export default pigglesCharacters;
