export const pigglesCharacters = {
  calendar: { id: "piggles-calendar", png: "/piggles/images/mascot/02/assets/png/piggles-calendar.png", webp: "/piggles/images/mascot/02/assets/webp/piggles-calendar.webp", alt: "Piggles Calendar" },
  celebrate: { id: "piggles-celebrate", png: "/piggles/images/mascot/02/assets/png/piggles-celebrate.png", webp: "/piggles/images/mascot/02/assets/webp/piggles-celebrate.webp", alt: "Piggles Celebrate" },
  deskScene: { id: "piggles-desk-scene", png: "/piggles/images/mascot/02/assets/png/piggles-desk-scene.png", webp: "/piggles/images/mascot/02/assets/webp/piggles-desk-scene.webp", alt: "Piggles Desk Scene" },
  invoice: { id: "piggles-invoice", png: "/piggles/images/mascot/02/assets/png/piggles-invoice.png", webp: "/piggles/images/mascot/02/assets/webp/piggles-invoice.webp", alt: "Piggles Invoice" },
  laptop: { id: "piggles-laptop", png: "/piggles/images/mascot/02/assets/png/piggles-laptop.png", webp: "/piggles/images/mascot/02/assets/webp/piggles-laptop.webp", alt: "Piggles Laptop" },
  neutral: { id: "piggles-neutral", png: "/piggles/images/mascot/02/assets/png/piggles-neutral.png", webp: "/piggles/images/mascot/02/assets/webp/piggles-neutral.webp", alt: "Piggles Neutral" },
  pointLeft: { id: "piggles-point-left", png: "/piggles/images/mascot/02/assets/png/piggles-point-left.png", webp: "/piggles/images/mascot/02/assets/webp/piggles-point-left.webp", alt: "Piggles Point Left" },
  thinking: { id: "piggles-thinking", png: "/piggles/images/mascot/02/assets/png/piggles-thinking.png", webp: "/piggles/images/mascot/02/assets/webp/piggles-thinking.webp", alt: "Piggles Thinking" },
  wave: { id: "piggles-wave", png: "/piggles/images/mascot/02/assets/png/piggles-wave.png", webp: "/piggles/images/mascot/02/assets/webp/piggles-wave.webp", alt: "Piggles Wave" }
};
export default pigglesCharacters;
