# SilicaUI Theme and Token Specification

## Source of truth

Piggles uses **SilicaUI** as the canonical implementation design system.

The product ships with two first-class themes:

- `piggles-light`
- `piggles-dark`

Both use the exact same semantic token names. Components must consume semantic SilicaUI tokens rather than hard-coded light- or dark-mode values.

## Required semantic colors

Piggles defines:

- `base-100`
- `base-200`
- `base-300`
- `base-content`
- `primary`
- `primary-content`
- `secondary`
- `secondary-content`
- `accent`
- `accent-content`
- `success`
- `success-content`
- `info`
- `info-content`
- `warning`
- `warning-content`
- `error`
- `error-content`

Additional named colors are allowed only for durable semantic concepts, and every additional color must define a matching `-content` color in **both** themes.

# Canonical Light Theme

| Token | Value | Purpose |
|---|---:|---|
| `base-100` | `#FFFFFF` | Primary MDI windows, cards, dialogs, editors |
| `base-200` | `#FBF7F8` | Workspace/background and recessed surfaces |
| `base-300` | `#F0E8EA` | Stronger neutral separation / selected neutral surfaces |
| `base-content` | `#202631` | Default readable ink |
| `primary` | `#FF6F86` | Canonical Piggles pink |
| `primary-content` | `#202631` | Content on primary |
| `secondary` | `#2D3443` | Deep navy/charcoal secondary brand surface |
| `secondary-content` | `#FFFFFF` | Content on secondary |
| `accent` | `#FFB3C0` | Soft supporting pink |
| `accent-content` | `#202631` | Content on accent |
| `success` | `#14804A` | Success/completed state |
| `success-content` | `#FFFFFF` | Content on success |
| `info` | `#2563EB` | Informational state |
| `info-content` | `#FFFFFF` | Content on info |
| `warning` | `#F3B61F` | Warning/attention state |
| `warning-content` | `#202631` | Content on warning |
| `error` | `#C93838` | Error/destructive state |
| `error-content` | `#FFFFFF` | Content on error |

# Canonical Dark Theme

| Token | Value | Purpose |
|---|---:|---|
| `base-100` | `#151922` | Primary MDI windows, cards, dialogs, editors |
| `base-200` | `#1C212C` | Workspace/background and recessed surfaces |
| `base-300` | `#272D39` | Elevated/selected dark surfaces |
| `base-content` | `#F4F5F7` | Default readable ink |
| `primary` | `#FF7C91` | Piggles pink tuned for dark backgrounds |
| `primary-content` | `#20151A` | Dark ink on primary |
| `secondary` | `#D7DBE3` | Light neutral secondary action/surface |
| `secondary-content` | `#1B1F28` | Dark ink on secondary |
| `accent` | `#8F4656` | Deeper supporting Piggles accent |
| `accent-content` | `#FFF4F6` | Light ink on accent |
| `success` | `#38B875` | Success/completed state |
| `success-content` | `#071A10` | Content on success |
| `info` | `#68A3FF` | Informational state |
| `info-content` | `#08162C` | Content on info |
| `warning` | `#F6C95B` | Warning/attention state |
| `warning-content` | `#241A04` | Content on warning |
| `error` | `#F06B6B` | Error/destructive state |
| `error-content` | `#250909` | Content on error |

# Brand continuity across themes

Dark mode is **not** an inverted version of light mode.

The brand must remain recognizably Piggles in both:

- Piggles pink remains `primary`.
- Base surfaces shift from white/warm-neutral to charcoal.
- Surfaces retain visible depth through `base-100`, `base-200`, and `base-300`.
- Pink is tuned slightly brighter in dark mode so it remains energetic without glowing.
- Status colors are tuned for dark surfaces while preserving semantic meaning.
- Typography, radius, iconography, logo geometry, and MDI behavior do not change by theme.

# MDI surface hierarchy

## Light

- workspace canvas → `base-200`
- standard MDI window → `base-100`
- recessed/secondary pane → `base-200`
- stronger neutral separation → `base-300`
- text/icons → `base-content`
- active/focused branded affordance → `primary`

## Dark

- workspace canvas → `base-200`
- standard MDI window → `base-100`
- recessed/secondary pane → `base-200`
- elevated/selected region → `base-300`
- text/icons → `base-content`
- active/focused branded affordance → `primary`

The hierarchy stays the same; only token values change.

# Content-pair rule

When a semantic color is used as a background, use its matching content token for direct content unless a tested component design intentionally overrides it.

Examples:

- `primary` → `primary-content`
- `secondary` → `secondary-content`
- `accent` → `accent-content`
- `success` → `success-content`
- `info` → `info-content`
- `warning` → `warning-content`
- `error` → `error-content`
- base surfaces → `base-content`

Never assume white text is correct on Piggles pink.

# Component rules

Prefer SilicaUI semantics:

- primary action → `primary`
- secondary action → `secondary`
- supporting branded emphasis → `accent`
- destructive action → `error`
- success state → `success`
- informational callout → `info`
- caution state → `warning`
- neutral work surfaces → base tokens

Do not create:
- `pinkButton`
- `darkCard`
- `warningGold`
- `lightModePanel`
- `darkModePanel`

if the semantic theme already expresses the intent.

# Theme switching

Theme switching should:

1. Change the active SilicaUI theme.
2. Preserve workspace/window state.
3. Preserve application state.
4. Avoid a full reload where practical.
5. Honor the user's explicit theme preference.
6. Support a system/default option if the product exposes it.

Recommended preference model:

- `system`
- `light`
- `dark`

The resolved theme becomes either `piggles-light` or `piggles-dark`.

# Charts and data visualization

Charts should not directly reuse arbitrary brand/status colors.

For chart palettes:
- define a dedicated semantic chart palette if needed,
- provide light and dark values,
- preserve categorical distinction,
- verify contrast against both base systems,
- do not use `error` or `success` for a series unless the data itself represents error/success.

# Additional named colors

Additional SilicaUI colors are allowed only when:

1. The name represents meaning, not hue.
2. The role recurs across the product.
3. Both light and dark values exist.
4. Both themes define `<name>-content`.
5. Contrast is validated.
6. The color is added to `config/brand.tokens.json`.
7. The use is documented here.

One-off mockup colors must not become product tokens.
